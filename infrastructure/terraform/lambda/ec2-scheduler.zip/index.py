import boto3
import os

def handler(event, context):
    ec2 = boto3.client('ec2')
    sns = boto3.client('sns')

    instance_id = os.environ['INSTANCE_ID']
    action = os.environ['ACTION']
    sns_topic = os.environ.get('SNS_TOPIC')

    # Check if this is a manual override check
    if event.get('source') == 'aws.events':
        # Check for manual override tag
        response = ec2.describe_instances(InstanceIds=[instance_id])
        tags = response['Reservations'][0]['Instances'][0].get('Tags', [])
        for tag in tags:
            if tag['Key'] == 'SchedulerOverride' and tag['Value'] == 'skip':
                print(f"Skipping {action} due to SchedulerOverride tag")
                return {'statusCode': 200, 'body': f'Skipped {action} - override active'}

    try:
        if action == 'stop':
            ec2.stop_instances(InstanceIds=[instance_id])
            message = f"EduNexus EC2 instance stopped (scheduled)"
        else:
            ec2.start_instances(InstanceIds=[instance_id])
            message = f"EduNexus EC2 instance started (scheduled)"

        print(message)

        # Send notification
        if sns_topic:
            sns.publish(
                TopicArn=sns_topic,
                Subject=f"EduNexus: EC2 {action.upper()}",
                Message=message
            )

        return {'statusCode': 200, 'body': message}
    except Exception as e:
        error_msg = f"Error {action}ing instance: {str(e)}"
        print(error_msg)
        return {'statusCode': 500, 'body': error_msg}
